OS_FinalProject
a work by Arash Harirpoosh(9731505) and Matin Tavakoli(9631805)
ticket locks and reader/writer implemented (20/1/24)
single thread in kernel mode added
multithread in kernel mode added
createThread system call added(this system call is for creating a thread for the current process)
getThreadid system call added(this system call is for returning current thread)
exitThread system call added(this system call is for exitting current thread)
joinThread system call added(current thread waits for another thread to terminate)
