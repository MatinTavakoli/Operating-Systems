#include "types.h"
#include "stat.h"
#include "user.h"
 
int
main(void)
{
  
  printf(1, "Done %d \n", changePolicy(1));
  printf(1, "Done %d \n", changePolicy(3));
  exit();
}
