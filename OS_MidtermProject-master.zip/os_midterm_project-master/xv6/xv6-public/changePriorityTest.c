#include "types.h"
#include "stat.h"
#include "user.h"

int
main(void)
{
printf(1, "Done %d\n", changePriority(2));
printf(1, "Done %d\n", changePriority(7));
exit();
}
